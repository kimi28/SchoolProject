#include "stdafx.h"
#include "DragRectangle.h"
#include "Mouse.h"



DragRectangle::DragRectangle(LPDIRECT3DDEVICE9 device)
	: device(device)
	, isDrag(FALSE)
	, start(0, 0)
	, end(0, 0)
{
	HRESULT hr;
	hr = D3DXCreateLine(device, &line);
	assert(SUCCEEDED(hr));

	rect = { 100, 100, 300, 300 };
	rectangle = { 500, 500, 700, 700 };

}


DragRectangle::~DragRectangle()
{
	SAFE_RELEASE(line);
}

void DragRectangle::Update()
{
	POINT position = Mouse::GetInstance()->GetPosition();
	if (IsPointInRect(position) == TRUE) {

		if (Mouse::GetInstance()->ButtonDown(0)) {
			isDrag = TRUE;
		}
		if (Mouse::GetInstance()->ButtonPress(0)) {
			//why?{
			start.x = Mouse::GetInstance()->GetPosition().x;
			start.y = Mouse::GetInstance()->GetPosition().y;
			end.x = Mouse::GetInstance()->GetPosition().x;
			end.y = Mouse::GetInstance()->GetPosition().y;

			rect.left = start.x - 100;
			rect.top = start.y - 100;
			rect.right = end.x + 100;
			rect.bottom = end.y + 100;
			//}
		}
		if (Mouse::GetInstance()->ButtonUp(0)) {

			isDrag = FALSE;
		}
	}
}

void DragRectangle::Render()
{
	D3DXCOLOR rectLineColor = D3DXCOLOR(0, 0, 0, 1);
	POINT position = Mouse::GetInstance()->GetPosition();
	if (IsPointInRect(position) == TRUE) {
		rectLineColor = D3DXCOLOR(1, 0, 0, 1);
	}

	RECT intersectRect;
	D3DXCOLOR rectangleLineColor = D3DXCOLOR(0, 0, 0, 1);
	if (IsIntersectRect(&intersectRect, &rect, &rectangle) == TRUE) {
		rectLineColor = D3DXCOLOR(1, 0, 0, 1);
		rectangleLineColor = D3DXCOLOR(0, 0, 1, 1);
	}


	D3DXVECTOR2 area[] = {
		D3DXVECTOR2(rect.left, rect.top),
		D3DXVECTOR2(rect.right, rect.top),
		D3DXVECTOR2(rect.right, rect.bottom),
		D3DXVECTOR2(rect.left, rect.bottom),
		D3DXVECTOR2(rect.left, rect.top),
	};

	D3DXVECTOR2 area2[] = {
		D3DXVECTOR2(rectangle.left, rectangle.top),
		D3DXVECTOR2(rectangle.right, rectangle.top),
		D3DXVECTOR2(rectangle.right, rectangle.bottom),
		D3DXVECTOR2(rectangle.left, rectangle.bottom),
		D3DXVECTOR2(rectangle.left, rectangle.top),
	};

	D3DXVECTOR2 area3[] = {
		D3DXVECTOR2(intersectRect.left, intersectRect.top),
		D3DXVECTOR2(intersectRect.right, intersectRect.top),
		D3DXVECTOR2(intersectRect.right, intersectRect.bottom),
		D3DXVECTOR2(intersectRect.left, intersectRect.bottom),
		D3DXVECTOR2(intersectRect.left, intersectRect.top),
	};

	line->Begin();
	line->Draw(area, 5, rectLineColor);
	line->Draw(area2, 5, rectangleLineColor);
	line->Draw(area3, 5, D3DXCOLOR(1, 1, 0, 1));
	line->End();
}

BOOL DragRectangle::IsPointInRect(POINT point)
{
	bool isCheck = true;
	isCheck &= rect.left <= point.x;
	isCheck &= rect.right >= point.x;
	isCheck &= rect.top <= point.y;
	isCheck &= rect.bottom >= point.y;
	if (isCheck == true) {
		return TRUE;
	}

	return FALSE;
}

BOOL DragRectangle::IsIntersectRect(LPRECT rect, const LPRECT rect1, const LPRECT rect2)
{
	bool isVertical = false;
	bool isHorizontal = false;

	if (rect1->left <= rect2->right && rect1->right >= rect2->left) {
		isHorizontal = true;

		if (rect != NULL) {
			rect->left = (rect1->left >= rect2->left) ? rect1->left : rect2->left;
			rect->right = (rect1->right <= rect2->right) ? rect1->right : rect2->right;
		}
	}
	if (rect1->top <= rect2->bottom && rect1->bottom >= rect2->top) {
		isVertical = true;

		if (rect != NULL) {
			rect->top = max(rect1->top, rect2->top);
			rect->bottom = min(rect1->bottom, rect2->bottom);
		}
	}

	if (isVertical == true && isHorizontal == true) {
		return TRUE;

		if (rect != NULL) {
			*rect = { 0,0,0,0 };
		}
	}
	return FALSE;
}
