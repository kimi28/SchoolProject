#pragma once
#include "DxWindow.h"

class DragRectangle;
class GameMain : public DxWindow
{
private:
	DragRectangle* rectangle;

public:
	GameMain(HINSTANCE hInstance, LPCWSTR className, LPCSTR lpCmdLine, int nCmdShow);
	~GameMain();

	void Initialize();
	void Destroy();
	void Update();
	void Render();
};

