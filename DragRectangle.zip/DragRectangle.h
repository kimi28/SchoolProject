#pragma once
class DragRectangle
{
public:
	DragRectangle(LPDIRECT3DDEVICE9 device);
	~DragRectangle();

	void Update();
	void Render();

	BOOL IsPointInRect(POINT point);
	BOOL IsIntersectRect(LPRECT rect, const LPRECT rect1, const LPRECT rect2);

private:
	LPDIRECT3DDEVICE9 device;

	LPD3DXLINE line;
	RECT rect;
	RECT rectangle;

	BOOL isDrag;
	D3DXVECTOR2 start;
	D3DXVECTOR2 end;

	float timeBegin = 0, timeEnd = 0;
};

