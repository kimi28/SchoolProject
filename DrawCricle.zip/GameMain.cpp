#include "stdafx.h"
#include "GameMain.h"
#include "DrawCricle.h"


GameMain::GameMain(HINSTANCE hInstance, LPCWSTR className, LPCSTR lpCmdLine, int nCmdShow)
	: DxWindow(hInstance, className, lpCmdLine, nCmdShow)
{
}


GameMain::~GameMain()
{
}

void GameMain::Initialize()
{
	cricle = new DrawCricle(device);
	cricle->Initalize();
}

void GameMain::Destroy()
{
	cricle->Destroy();
	SAFE_DELETE(cricle);

	Keyboard::DeleteInstance();
	Mouse::DeleteInstance();
}

void GameMain::Update()
{
	Keyboard::GetInstance()->Update();
	Mouse::GetInstance()->Update();

	cricle->Update();
}

void GameMain::Render()
{
	if (device == NULL)
		return;

	device->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, D3DXCOLOR(1, 1, 1, 1), 1.0f, 0);

	device->BeginScene();

	cricle->Render();

	device->EndScene();
	device->Present(0, 0, 0, 0);
}
