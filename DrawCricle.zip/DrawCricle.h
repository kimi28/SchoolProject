#pragma once
class DrawCricle
{
public:
	DrawCricle(LPDIRECT3DDEVICE9 device);
	~DrawCricle();

	void Initalize();
	void Destroy();
	void Update();
	void Render();

	void Cricle(POINT point, int radius, int side, DWORD color);

	BOOL IsPointInCricle(POINT position, POINT point, int radius);
	BOOL IsIntersectCricle(POINT point, POINT point2, int radius);

private:
	LPDIRECT3DDEVICE9 device;
	LPD3DXLINE line;

	BOOL isDrag;
	POINT start;
	POINT end;

	POINT point;
	POINT point2;


	float distance;
};

