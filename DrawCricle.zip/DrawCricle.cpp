#include "stdafx.h"
#include "DrawCricle.h"



DrawCricle::DrawCricle(LPDIRECT3DDEVICE9 device)
	: device(device)
	, isDrag(FALSE)
{
	start = { 0,0 };
	end = { 0 };
	point = { 200, 200 };
	point2 = { 600, 600 };
}

DrawCricle::~DrawCricle()
{
}

void DrawCricle::Initalize()
{
	HRESULT hr;
	hr = D3DXCreateLine(device, &line);
	assert(SUCCEEDED(hr));

	line->SetAntialias(TRUE);
}

void DrawCricle::Destroy()
{
	SAFE_RELEASE(line);
}

void DrawCricle::Update()
{
	POINT position = Mouse::GetInstance()->GetPosition();
	if (IsPointInCricle(position, point, 100) == TRUE) {
		if (Mouse::GetInstance()->ButtonDown(0)) {
			isDrag = TRUE;
		}
		if (Mouse::GetInstance()->ButtonPress(0)) {
			start = Mouse::GetInstance()->GetPosition();

			point.x = start.x;
			point.y = start.y;
		}
		if (Mouse::GetInstance()->ButtonUp(0)) {
			isDrag = FALSE;
		}
	}

}

void DrawCricle::Render()
{
	D3DXCOLOR cricleColor = D3DXCOLOR(0, 0, 0, 1);
	POINT position = Mouse::GetInstance()->GetPosition();
	if (IsPointInCricle(position, point, 100) == TRUE) {
		cricleColor = D3DXCOLOR(1, 0, 0, 1);
	}

	D3DXCOLOR cricleleLineColor = D3DXCOLOR(0, 0, 0, 1);
	if (IsIntersectCricle(point, point2, 100) == TRUE) {
		cricleColor = D3DXCOLOR(0, 1, 0, 1);
		cricleleLineColor = D3DXCOLOR(0, 0, 1, 1);
	}


	Cricle(point, 100, 40, cricleColor);
	Cricle(point2, 100, 40, cricleleLineColor);
}

void DrawCricle::Cricle(POINT point, int radius, int side, DWORD color)
{
	D3DXVECTOR2 drawVec[128];

	int count = 0;
	float step = M_PI * 2.0f / side;
	for (float i = 0; i < M_PI * 2.0f; i += step) {
		D3DXVECTOR2 v1;
		D3DXVECTOR2 v2;

		v1.x = radius * cos(i) + point.x;
		v1.y = radius * sin(i) + point.y;
		v2.x = radius * cos(i + step) + point.x;
		v2.y = radius * sin(i + step) + point.y;

		drawVec[count] = v1;
		drawVec[count+1] = v2;

		count += 2;
	}

	line->Begin();
	line->Draw(drawVec, count, color);
	line->End();
}

BOOL DrawCricle::IsPointInCricle(POINT position, POINT point, int radius)
{
	float lenght;
	float deltaX = position.x - point.x;
	float deltaY = position.y - point.y;

	lenght = sqrt(abs(deltaX * deltaX + deltaY * deltaY));

	if (lenght <= radius) {
		return TRUE;
	}

	return FALSE;
}

BOOL DrawCricle::IsIntersectCricle(POINT point, POINT point2, int radius)
{
	float lenght;
	float deltaX = point2.x - point.x;
	float deltaY = point2.y - point.y;

	lenght = sqrt(abs(deltaX * deltaX + deltaY * deltaY));


	if (lenght <= radius * 2) {
		return TRUE;
	}

	return FALSE;
}
